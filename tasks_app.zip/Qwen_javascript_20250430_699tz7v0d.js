function addTask() {
    const input = document.getElementById("taskInput");
    const taskText = input.value.trim();
    
    if (taskText === "") {
        alert("Por favor, escribe una tarea.");
        return;
    }

    const li = document.createElement("li");
    li.innerHTML = `${taskText} <button onclick="deleteTask(this)">Eliminar</button>`;
    
    document.getElementById("taskList").appendChild(li);
    input.value = "";
}

function deleteTask(button) {
    const li = button.parentElement;
    li.remove();
}